var UnoAppManifest = {
    displayName: "UnoWASMnet80"
}
